"""Local stand-in for the GVCW booking page, used only for testing the bot.

Same element IDs, same API paths and JSON shapes as recorded on 2026-10-11.
Also plays ntfy (OTP stream + notify endpoint). Behaviour:
  * the target month is "closed" until RELEASE_AFTER_S seconds after start
  * then a few dates have free slots; booking a slot twice is refused
  * requesting an OTP publishes "P<n> GVCW-OTP Your code is 4xxxxx" on the OTP topic
  * the fake reCAPTCHA "solves itself" 2 s after it is shown (stands in for the human)
Run:  python tests/mock_site.py --port 8765 --jquery path/to/jquery.min.js
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import random
import time

from aiohttp import web

RELEASE_AFTER_S = float(os.environ.get("MOCK_RELEASE_S", "8"))
FREE = {  # date -> list of (slot id, start time)
    "03/11/2026": [(5001, "09:30"), (5002, "09:45")],
    "10/11/2026": [(5101, "10:00")],
    "17/11/2026": [(5201, "10:15"), (5202, "10:30"), (5203, "10:45")],
}
TIMES = ["09:30", "09:45", "10:00", "10:15", "10:30", "10:45", "11:00", "11:15"]

PAGE = """<!doctype html><html><head><title>Visa | My Appointments | Add</title>
<script src="/dist/js/jquery.min.js"></script>
<style>.appointment_slot{display:inline-block;padding:4px;margin:2px;border:1px solid #333}
.appointment_slot_enabled{background:#cfc;cursor:pointer}.appointment_slot_selected{background:#6c6}
.hidden{display:none}</style></head><body>
<a href="/user/1">Manage Account</a>
<form id="appointment">
<input type="hidden" id="vac" name="vac" value="137">
<select id="type" name="type"><option value="0">C</option><option value="2">D</option><option value="26">D seasonal</option></select>
<select id="travelpurposes" name="travelpurposes"><option value="" selected></option></select>
<select id="bookingfor" name="bookingfor"><option value="0" selected>Individual</option><option value="1">Group</option></select>
<select id="members" name="members"><option>2</option></select>
<input id="ind_email" name="email" readonly value="__EMAIL__">
<select id="phonenumberprefix" name="phonenumberprefix[id]"><option value=""></option><option value="197" selected>PAKISTAN +92</option></select>
<input id="ind_phonenumber" name="phonenumber" value="">
<input id="gp_surname" name="applicants[][surname]"><input id="gp_firstname" name="applicants[][firstname]">
<input id="gp_dateofbirth" name="applicants[][dateofbirth]"><input id="gp_passportnumber" name="applicants[][passportnumber]">
<input id="gp_traveldocumentvaliduntil" name="applicants[][traveldocumentvaliduntil]">
<select id="gp_gender" name="applicants[][gender[id]]"><option value=""></option><option value="1">FEMALE</option><option value="2">MALE</option></select>
<select id="gp_nationality" name="applicants[][nationality[id]]"><option value=""></option><option value="197" selected>PAKISTAN</option></select>
<input type="hidden" id="gp_periodslotid" name="applicants[][periodslotid]">
<select id="appointmentmethod" name="appointmentmethod"><option value="1" selected>1</option></select>
<input id="datefrom" name="datefrom" value="">
<input type="hidden" id="selectedtime" name="selectedtime" value="">
<button type="button" id="btn-search" onclick="selectPeriodslot(this);">Search</button>
<div id="resultDiv"></div>
<div id="btn-onetimepassword-wrap"><button type="button" id="btn-onetimepassword" onclick="sendOTP()">Request OTP</button></div>
<div id="onetimepassword-wrap" style="display:none"><input id="onetimepassword" name="onetimepassword"></div>
<input type="checkbox" id="submitinfo" name="submitinfo" style="display:none">
<div id="recaptcha" class="g-recaptcha" style="display:none">[fake captcha]</div>
<textarea id="g-recaptcha-response" name="g-recaptcha-response" style="display:none"></textarea>
<button type="button" id="btn-new-appointment" style="display:none" onclick="book()">Book</button>
<div class="ajs-message" id="err"></div>
</form>
<script>
var captchaShownAt = 0;
window.grecaptcha = { getResponse: function(){ return (captchaShownAt && Date.now() - captchaShownAt > 2000) ? 'tok-' + captchaShownAt : ''; } };
function selectPeriodslot(btn){
  var body = {datefrom: $('#datefrom').val(), type: +$('#type').val(), bookingfor: +$('#bookingfor').val(), members: 1,
              method: +$('#appointmentmethod').val(), travelpurposes: -1, howmanyapplicantsareunder12: 0,
              appointmentId: "undefined", id: 0, vac: {id: +$('#vac').val()}};
  $.ajax({url: '/api/v1/periodslot/slots', type: 'PUT', data: JSON.stringify(body), contentType: 'application/json; charset=utf-8'})
   .done(function(data){
     $('#result').remove();
     if (data.code !== 'SUCCESS') { $('#err').text(data.message); return; }
     var html = '<div id="result">';
     data.returnobject.slots.forEach(function(s){
       if (s.isavailable && s.isselectable) html += '<div id="t_'+s.id+'" class="appointment_slot appointment_slot_enabled" onclick="selectTime('+s.id+',\\''+s.starttime+'\\')">'+s.starttime+'</div>';
       else html += '<div class="appointment_slot appointment_slot_disabled">'+s.starttime+'</div>';
     });
     $('#resultDiv').append(html + '</div>');
   });
}
function selectTime(id, time){
  $("div[id^='t_']").removeClass('appointment_slot_selected');
  $('#t_'+id).addClass('appointment_slot_selected'); $('#selectedtime').val(time); $('#gp_periodslotid').val(id);
}
function sendOTP(){
  $.ajax({type: 'POST', url: '/api/v1/onetimepassword/sendOtpBookAppointment/' + $('#ind_phonenumber').val() + '/' + $('#phonenumberprefix').val(),
          data: JSON.stringify({datefrom: $('#datefrom').val(), selectedtime: $('#selectedtime').val()}), contentType: 'application/json'})
   .done(function(data){
     if (data.code === 'SUCCESS') { $('#onetimepassword-wrap').show(); $('#submitinfo').show(); $('#btn-new-appointment').show();
       $('#recaptcha').show(); captchaShownAt = Date.now(); $('#btn-onetimepassword-wrap').hide();
       setTimeout(function(){ $('#btn-onetimepassword-wrap').show(); }, 120000); }
   });
}
function book(){
  if (!$('#submitinfo').is(':checked')) { $('#err').text('accept terms'); return; }
  var body = {slot: +$('#gp_periodslotid').val(), otp: $('#onetimepassword').val(), phone: $('#ind_phonenumber').val(),
              captcha: grecaptcha.getResponse(), passport: $('#gp_passportnumber').val(), surname: $('#gp_surname').val(),
              dob: $('#gp_dateofbirth').val(), gender: $('#gp_gender').val()};
  $.ajax({type: 'POST', url: '/appointments', data: JSON.stringify(body), contentType: 'application/json'})
   .done(function(data){ if (data.code === 'SUCCESS') location.href = '/appointments/result/' + data.returnobject; else $('#err').text(data.message); });
}
</script></body></html>"""


class State:
    def __init__(self):
        self.t0 = time.time()
        self.taken: dict[int, str] = {}
        self.otps: dict[str, str] = {}
        self.otp_queue: list[dict] = []
        self.notifications: list[dict] = []
        self.bookings: list[dict] = []
        self.slot_requests = 0
        self.phone_to_key: dict[str, str] = {}

    @property
    def released(self) -> bool:
        return time.time() - self.t0 >= RELEASE_AFTER_S


def make_app(jquery_path: str, phone_to_key: dict[str, str]) -> web.Application:
    st = State()
    st.phone_to_key = phone_to_key
    app = web.Application()
    app["state"] = st

    async def page(request):
        return web.Response(text=PAGE.replace("__EMAIL__", "test@example.com"), content_type="text/html")

    async def login(request):
        raise web.HTTPFound("/appointments/add")

    async def jq(request):
        return web.FileResponse(jquery_path)

    async def result(request):
        return web.Response(text=f"<html><body>Appointment {request.match_info['rid']} confirmed</body></html>", content_type="text/html")

    async def slots(request):
        st.slot_requests += 1
        body = await request.json()
        day = body.get("datefrom", "")
        assert body.get("vac") == {"id": 137} and body.get("type") == 26, body
        if day.endswith("/11/2026") and not st.released:  # real site: SUCCESS with an empty slot list
            return web.json_response({"message": "", "returnobject": {"slots": [], "payment": False}, "code": "SUCCESS"})
        free = {sid: t for sid, t in FREE.get(day, []) if sid not in st.taken}
        out = []
        for i, t in enumerate(TIMES):
            sid = next((k for k, v in free.items() if v == t), None)
            out.append({"id": sid, "periodid": 1, "starttime": t, "numofavailableslots": 1 if sid else 0,
                        "isavailable": bool(sid), "isselectable": bool(sid)})
        return web.json_response({"message": "", "returnobject": {"slots": out, "payment": False}, "code": "SUCCESS"})

    async def otp(request):
        phone = request.match_info["phone"]
        # a competitor grabs 09:45 on 03/11 while our first person waits for the SMS -> exercises the retry path
        st.taken.setdefault(5002, "competitor")
        code = str(random.randint(400000, 499999))
        st.otps[phone] = code
        key = st.phone_to_key.get(phone, "P?")

        async def deliver():
            await asyncio.sleep(random.uniform(1.0, 3.0))  # SMS delay
            st.otp_queue.append({"event": "message", "id": f"m{len(st.otp_queue)}", "time": int(time.time()), "message": f"{key} GVCW-OTP Your code is {code}. Valid 5 min (ref 2026)"})
        asyncio.create_task(deliver())
        return web.json_response({"message": "sent", "code": "SUCCESS"})

    async def book(request):
        b = await request.json()
        hang = os.environ.get("MOCK_HANG_FIRST_BOOK") == "1" and not st.bookings and not getattr(st, "hung", False)
        if not b.get("captcha"):
            return web.json_response({"message": "captcha missing", "code": "INVALID"})
        if st.otps.get(b.get("phone")) != b.get("otp"):
            return web.json_response({"message": "Wrong OTP code", "code": "INVALID"})
        sid = int(b.get("slot") or 0)
        if sid in st.taken:
            return web.json_response({"message": "The selected time slot is no longer available", "code": "INVALID"})
        st.taken[sid] = b.get("phone")
        st.bookings.append(b)
        if hang:  # booking is stored, but the reply arrives far too late (overloaded server)
            st.hung = True
            await asyncio.sleep(60)
        return web.json_response({"message": "ok", "returnobject": 900000 + sid, "code": "SUCCESS"})

    async def ntfy_stream(request):
        resp = web.StreamResponse()
        resp.content_type = "application/x-ndjson"
        await resp.prepare(request)
        await resp.write(b'{"event":"open"}\n')
        sent = 0
        while True:
            while sent < len(st.otp_queue):
                await resp.write((json.dumps(st.otp_queue[sent]) + "\n").encode())
                sent += 1
            await asyncio.sleep(0.2)

    async def ntfy_publish(request):
        st.notifications.append(await request.json())
        return web.json_response({"ok": True})

    async def status(request):
        return web.json_response({"taken": st.taken, "bookings": st.bookings, "slot_requests": st.slot_requests,
                                  "notifications": len(st.notifications), "released": st.released})

    app.router.add_get("/login/appointments/en", login)
    app.router.add_get("/appointments/add", page)
    app.router.add_get("/appointments/result/{rid}", result)
    app.router.add_get("/dist/js/jquery.min.js", jq)
    app.router.add_put("/api/v1/periodslot/slots", slots)
    app.router.add_post("/api/v1/onetimepassword/sendOtpBookAppointment/{phone}/{prefix}", otp)
    app.router.add_post("/appointments", book)
    app.router.add_get("/_status", status)
    app.router.add_post("/", ntfy_publish)
    app.router.add_get("/{topic}/json", ntfy_stream)
    return app


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--jquery", required=True)
    ap.add_argument("--phones", default="3001234567:P1,3001234568:P2,3001234569:P3,3001234570:P4")
    a = ap.parse_args()
    mapping = dict(x.split(":") for x in a.phones.split(","))
    web.run_app(make_app(a.jquery, mapping), host="127.0.0.1", port=a.port)
