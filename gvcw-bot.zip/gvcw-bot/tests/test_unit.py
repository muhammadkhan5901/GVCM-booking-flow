from datetime import date
from pathlib import Path

import pytest

from gvcw.config import ConfigError, load_config
from gvcw.relay import extract_code, parse_relay_message
from gvcw.site import BLOCKED, CLOSED, LOGGED_OUT, OPEN, classify_slots_result, month_dates, slots_body

EXAMPLE = Path(__file__).resolve().parent.parent / "config.example.yaml"

RECORDED_FULL_DAY = {  # trimmed copy of the real response captured on 2026-10-11
    "message": "",
    "returnobject": {"slots": [
        {"id": None, "periodid": 14693, "starttime": "09:30", "numofavailableslots": 0, "isavailable": False, "isselectable": False},
        {"id": None, "periodid": 14693, "starttime": "09:45", "numofavailableslots": 0, "isavailable": False, "isselectable": False},
    ]},
    "code": "SUCCESS",
}


def _cfg(tmp_path, **over):
    text = EXAMPLE.read_text(encoding="utf-8")
    text = text.replace("CHANGE-ME-otp-topic", "otp-aaaaaaaaaaaaaaaaaaaaaaaa").replace("CHANGE-ME-alert-topic", "alert-bbbbbbbbbbbbbbbbbbbbbbbb")
    for k, v in over.items():
        text = text.replace(k, v)
    p = tmp_path / "config.yaml"
    p.write_text(text, encoding="utf-8")
    return load_config(p)


def test_example_config_loads(tmp_path):
    cfg = _cfg(tmp_path)
    assert len(cfg.persons) == 4 and cfg.vac_id == 137 and cfg.type_id == 26
    assert cfg.persons[0].gender_id == "2"


def test_example_topics_rejected(tmp_path):
    p = tmp_path / "config.yaml"
    p.write_text(EXAMPLE.read_text(encoding="utf-8"), encoding="utf-8")
    with pytest.raises(ConfigError):
        load_config(p)


def test_bad_date_rejected(tmp_path):
    with pytest.raises(ConfigError):
        _cfg(tmp_path, **{'dob: "31/12/1990"         # DD/MM/YYYY exactly as on passport': 'dob: "1990-12-31"'})


def test_phone_normalised(tmp_path):
    cfg = _cfg(tmp_path, **{'phone: "3001234567"       # 10 digits, no 0 and no +92': 'phone: "+923001234567"'})
    assert cfg.persons[0].phone == "3001234567"


def test_month_dates_skips_past_and_weekdays(tmp_path):
    cfg = _cfg(tmp_path)
    days = month_dates(cfg, today=date(2026, 10, 11))
    assert days[0] == "01/11/2026" and days[-1] == "30/11/2026" and len(days) == 30
    cfg.skip_weekdays = [5, 6]
    days = month_dates(cfg, today=date(2026, 11, 15))
    assert days[0] == "16/11/2026" and all(d not in days for d in ("21/11/2026", "22/11/2026"))


def test_slots_body_matches_site():
    class C:
        type_id, method, travel_purpose, vac_id = 26, 1, -1, 137
    b = slots_body(C, "13/10/2026")
    assert b == {"datefrom": "13/10/2026", "type": 26, "bookingfor": 0, "members": 1, "method": 1, "travelpurposes": -1,
                 "howmanyapplicantsareunder12": 0, "appointmentId": "undefined", "id": 0, "vac": {"id": 137}}


def test_classify():
    r = classify_slots_result("13/10/2026", {"ok": True, "http": 200, "data": RECORDED_FULL_DAY})
    assert r.kind == OPEN and r.free == []
    data = {"code": "SUCCESS", "returnobject": {"slots": [{"id": 7, "starttime": "10:00", "numofavailableslots": 1, "isavailable": True, "isselectable": True},
                                                          {"id": 8, "starttime": "10:15", "numofavailableslots": 1, "isavailable": True, "isselectable": False}]}}
    r = classify_slots_result("d", {"ok": True, "http": 200, "data": data})
    assert [s.id for s in r.free] == [7]
    r = classify_slots_result("d", {"ok": True, "http": 200, "data": {"code": "INVALID", "message": "You cannot book an appointment on this date"}})
    assert r.kind == CLOSED
    # live reply for 01/11/2026 on 2026-10-11 (month not released yet)
    r = classify_slots_result("01/11/2026", {"ok": True, "http": 200, "data": {"message": "", "returnobject": {"slots": []}, "code": "SUCCESS"}})
    assert r.kind == CLOSED
    r = classify_slots_result("d", {"ok": True, "http": 200, "data": "<html>Sign in to GVCW</html>"})
    assert r.kind == LOGGED_OUT
    r = classify_slots_result("d", {"ok": False, "http": 403, "snippet": "Request unsuccessful. Incapsula incident ID"})
    assert r.kind == BLOCKED


def test_otp_parsing():
    pat = r"\b(\d{4,8})\b"
    assert parse_relay_message("P1 GVCW Your OTP is 482913", pat) == ("P1", "482913")
    assert parse_relay_message("P1", pat) is None
    assert extract_code("no digits here", pat) is None
