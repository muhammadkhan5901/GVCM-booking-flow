"""End-to-end test against tests/mock_site.py with real Chromium over CDP (Linux, headless).

python tests/e2e_mock.py --chrome /path/to/chrome --jquery /path/to/jquery.min.js
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PORT = 8765

CONFIG = """
base_url: http://127.0.0.1:{port}
chrome_path: "{chrome}"
profiles_dir: profiles
logs_dir: logs
target:
  month: "2026-11"
timing:
  request_gap_s: 0.2
  sweep_pause_s: 1.0
  closed_check_every_s: 3
  monitor_sweep_every_s: 5
  keepalive_every_s: 4
  otp_timeout_s: 30
  captcha_timeout_s: 30
  book_timeout_s: 20
relay:
  server: http://127.0.0.1:{port}
  otp_topic: otp-test-topic-aaaaaaaaaaaa
  notify_topic: alert-test-topic-bbbbbbbbbb
persons:
""" + "".join(
    f"""
  - key: P{i}
    port: {9300 + i}
    account_email: "p{i}@example.com"
    phone: "{3001234566 + i}"
    surname: "TEST{i}"
    firstname: "PERSON"
    dob: "0{i}/01/1990"
    passport: "AB000000{i}"
    passport_expiry: "01/01/2030"
    gender: {"FEMALE" if i == 2 else "MALE"}
""" for i in range(1, 5))


def status():
    with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/_status", timeout=5) as r:
        return json.loads(r.read())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--chrome", required=True)
    ap.add_argument("--jquery", required=True)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--hang-first-book", action="store_true")
    a = ap.parse_args()

    work = Path(tempfile.mkdtemp(prefix="gvcw-e2e-"))
    wrapper = work / "chrome-headless.sh"
    wrapper.write_text(f'#!/bin/sh\nexec "{a.chrome}" --headless=new --no-sandbox --disable-gpu "$@"\n')
    wrapper.chmod(0o755)
    cfg = work / "config.yaml"
    cfg.write_text(CONFIG.format(port=PORT, chrome=wrapper), encoding="utf-8")

    env = dict(os.environ, MOCK_RELEASE_S="40", PYTHONPATH=str(ROOT))
    if a.hang_first_book:
        env["MOCK_HANG_FIRST_BOOK"] = "1"
    server = subprocess.Popen([sys.executable, str(ROOT / "tests" / "mock_site.py"), "--port", str(PORT), "--jquery", a.jquery,
                               "--phones", "3001234567:P1,3001234568:P2,3001234569:P3,3001234570:P4"], env=env)
    procs = [server]
    try:
        time.sleep(2)
        gv = [sys.executable, "-m", "gvcw", "-c", str(cfg)]
        subprocess.run(gv + ["launch"], cwd=work, env=env, check=True)
        time.sleep(4)
        chk = subprocess.run(gv + ["check"], cwd=work, env=env)
        print("check exit code", chk.returncode)
        run_args = gv + ["run", "--rush-minutes", "1"] + (["--dry-run"] if a.dry_run else [])
        t0 = time.time()
        res = subprocess.run(run_args, cwd=work, env=env, timeout=240)
        print(f"run exit code {res.returncode} in {time.time() - t0:.1f}s")
        st = status()
        print(json.dumps(st, indent=1))
        if a.dry_run:
            assert not st["bookings"], "dry run must not book"
        elif a.hang_first_book:
            phones = [b["phone"] for b in st["bookings"]]
            assert len(phones) == len(set(phones)), f"someone was booked twice: {phones}"
            assert len(phones) == 4, phones
        else:
            ours = {int(k): v for k, v in st["taken"].items() if v != "competitor"}
            assert len(st["bookings"]) == 4, "expected 4 bookings"
            assert len(set(ours)) == 4 and 5002 not in ours, ours
            phones = sorted(b["phone"] for b in st["bookings"])
            assert phones == ["3001234567", "3001234568", "3001234569", "3001234570"], phones
            for b in st["bookings"]:
                i = int(b["phone"]) - 3001234566
                assert b["passport"] == f"AB000000{i}" and b["surname"] == f"TEST{i}", b
                assert b["gender"] == ("1" if i == 2 else "2"), b
        shots = list((work / "logs" / "screens").glob("*.png"))
        print(f"screenshots: {len(shots)}  logs: {work / 'logs'}")
        print("E2E PASSED")
    finally:
        subprocess.run(["pkill", "-f", "remote-debugging-port=930"], check=False)
        for p in procs:
            p.terminate()
        shutil.copytree(work / "logs", ROOT / "tests" / "_last_e2e_logs", dirs_exist_ok=True) if (work / "logs").exists() else None


if __name__ == "__main__":
    main()
