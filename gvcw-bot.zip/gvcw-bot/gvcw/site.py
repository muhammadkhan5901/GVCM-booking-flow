"""Everything that knows about the GVCW page: API calls, selectors, result parsing.

All requests are made from inside the logged-in page with the page's own jQuery,
so they carry the same cookies and headers as a normal click on "Search".
"""
from __future__ import annotations

import calendar
from dataclasses import dataclass
from datetime import date, timedelta

from .config import Config, Person

SLOTS_API = "/api/v1/periodslot/slots"
OTP_API_PART = "/api/v1/onetimepassword/sendOtpBookAppointment/"

# Result kinds returned by classify_slots_result
OPEN = "open"            # month/date is bookable (may still have 0 free slots)
CLOSED = "closed"        # site refuses this date (not released yet / out of range)
LOGGED_OUT = "logged_out"
BLOCKED = "blocked"      # firewall page instead of JSON
ERROR = "error"


@dataclass
class Slot:
    id: int
    start: str
    available: int


@dataclass
class DayResult:
    date: str
    kind: str
    free: list[Slot]
    message: str = ""
    http: int = 0


# ---------------------------------------------------------------- pure helpers

def month_dates(cfg: Config, today: date | None = None) -> list[str]:
    """All DD/MM/YYYY dates of the target month that the site could accept (from tomorrow on)."""
    today = today or date.today()
    y, m = cfg.month_bounds()
    first = date(y, m, 1)
    last = date(y, m, calendar.monthrange(y, m)[1])
    start = max(first, today + timedelta(days=1))
    out = []
    d = start
    while d <= last:
        if d.weekday() not in cfg.skip_weekdays:
            out.append(d.strftime("%d/%m/%Y"))
        d += timedelta(days=1)
    return out


def slots_body(cfg: Config, day: str) -> dict:
    """Exact JSON the site's own selectPeriodslot() sends for an individual booking."""
    return {
        "datefrom": day,
        "type": cfg.type_id,
        "bookingfor": 0,
        "members": 1,
        "method": cfg.method,
        "travelpurposes": cfg.travel_purpose,
        "howmanyapplicantsareunder12": 0,
        "appointmentId": "undefined",
        "id": 0,
        "vac": {"id": cfg.vac_id},
    }


def free_slots(data: dict) -> list[Slot]:
    slots = ((data or {}).get("returnobject") or {}).get("slots") or []
    out = []
    for s in slots:
        if s.get("isavailable") and s.get("isselectable") and s.get("id") is not None:
            out.append(Slot(id=int(s["id"]), start=str(s.get("starttime", "")), available=int(s.get("numofavailableslots") or 0)))
    return out


def success_result(day: str, data: dict, http: int = 200) -> DayResult:
    """Verified on the live site (2026-10-11): a date that is not released yet answers
    code SUCCESS with an EMPTY slot list, while a released date answers its 8 slots
    (all marked unavailable when fully booked). So: no slots at all = CLOSED."""
    slots = ((data or {}).get("returnobject") or {}).get("slots") or []
    if not slots:
        return DayResult(day, CLOSED, [], message="no slots published for this date", http=http)
    return DayResult(day, OPEN, free_slots(data), http=http)


def classify_slots_result(day: str, res: dict) -> DayResult:
    """Turn the raw result of SLOTS_JS into a DayResult."""
    http = int(res.get("http") or 0)
    if res.get("ok"):
        data = res.get("data")
        if isinstance(data, dict):
            code = str(data.get("code", "")).upper()
            if code == "SUCCESS":
                return success_result(day, data, http)
            return DayResult(day, CLOSED, [], message=str(data.get("message") or code), http=http)
        text = str(data or "")[:300]
        return DayResult(day, _classify_text(text), [], message=text, http=http)
    snippet = str(res.get("snippet") or "")
    if http in (401, 403) and "incapsula" not in snippet.lower():
        return DayResult(day, LOGGED_OUT, [], message=snippet, http=http)
    kind = _classify_text(snippet)
    if kind == ERROR and http == 0:
        return DayResult(day, ERROR, [], message=f"{res.get('status')} {res.get('err')}", http=http)
    return DayResult(day, kind, [], message=snippet or f"{res.get('status')} {res.get('err')}", http=http)


def _classify_text(text: str) -> str:
    low = text.lower()
    if "incapsula" in low or "request unsuccessful" in low or "access denied" in low:
        return BLOCKED
    if "sign in" in low or "login" in low or "password" in low:
        return LOGGED_OUT
    return ERROR


# ---------------------------------------------------------------- in-page JS

SLOTS_JS = """
async ({url, body}) => {
  if (!window.jQuery) return {ok: false, http: 0, status: 'nojquery', err: 'jQuery not on page', snippet: document.title};
  return await new Promise((resolve) => {
    jQuery.ajax({url, type: 'PUT', data: JSON.stringify(body), contentType: 'application/json; charset=utf-8',
                 global: false, timeout: 25000})
      .done((data, status, xhr) => resolve({ok: true, http: xhr.status, data}))
      .fail((xhr, status, err) => resolve({ok: false, http: xhr.status, status, err: String(err),
                                          snippet: (xhr.responseText || '').slice(0, 400)}));
  });
}
"""

PAGE_STATE_JS = """
() => ({
  url: location.href,
  hasForm: !!document.querySelector('form#appointment'),
  hasLogin: !!document.querySelector('input[type=password]'),
  jq: !!window.jQuery,
  user: (document.querySelector('a[href^="/user/"]') || {}).href || null
})
"""

FILL_FORM_JS = """
(p) => {
  const $ = window.jQuery;
  const res = {};
  const setSel = (sel, v) => {
    const el = $(sel);
    if (!el.length) { res[sel] = 'missing'; return; }
    if (String(el.val()) !== String(v)) el.val(String(v)).trigger('change');
    res[sel] = String(el.val()) === String(v) ? 'ok' : 'got ' + el.val();
  };
  const setTxt = (sel, v, onlyIfEmpty) => {
    const el = $(sel);
    if (!el.length) { res[sel] = 'missing'; return; }
    const cur = String(el.val() || '').trim();
    if (onlyIfEmpty && cur !== '') { res[sel] = cur.toUpperCase() === String(v).toUpperCase() ? 'ok' : 'kept site value'; return; }
    if (el.prop('readonly') || el.prop('disabled')) { res[sel] = cur === String(v) ? 'ok' : 'readonly ' + cur; return; }
    el.val(v).trigger('input').trigger('change');
    res[sel] = String(el.val()) === String(v) ? 'ok' : 'got ' + el.val();
  };
  if (p.step === 'type') { setSel('#type', p.type_id); return res; }
  setSel('#bookingfor', '0');
  setSel('#appointmentmethod', p.method);
  setTxt('#ind_email', p.email, true);
  setSel('#phonenumberprefix', p.phone_prefix_id);
  setTxt('#ind_phonenumber', p.phone, true);
  setTxt('#gp_surname', p.surname, false);
  setTxt('#gp_firstname', p.firstname, false);
  setTxt('#gp_dateofbirth', p.dob, false);
  setTxt('#gp_passportnumber', p.passport, false);
  setTxt('#gp_traveldocumentvaliduntil', p.passport_expiry, false);
  setSel('#gp_gender', p.gender_id);
  setSel('#gp_nationality', p.nationality_id);
  return res;
}
"""

SET_DATE_JS = """
(d) => { const el = jQuery('#datefrom'); el.val(d).trigger('change'); return el.val(); }
"""

SLOT_SELECTED_JS = """
(id) => ({
  selected: !!document.querySelector('#t_' + id + '.appointment_slot_selected'),
  time: (document.querySelector('#selectedtime') || {}).value || ''
})
"""

CAPTCHA_TOKEN_JS = """
() => {
  try { if (window.grecaptcha && grecaptcha.getResponse) return grecaptcha.getResponse() || ''; } catch (e) {}
  const t = document.querySelector('#g-recaptcha-response');
  return t ? (t.value || '') : '';
}
"""

# Captures the server's reply to the final POST /appointments inside the page itself
# (sessionStorage survives the jump to the result page), so the outcome is never lost.
BOOK_HOOK_JS = """
() => {
  try { sessionStorage.removeItem('gvcwBook'); } catch (e) {}
  window.__gvcwBook = null;
  if (window.jQuery && !window.__gvcwHooked) {
    window.__gvcwHooked = true;
    jQuery.ajaxPrefilter(function (options, orig, jqXHR) {
      var u = String(options.url || '').split('?')[0].replace(/\\/+$/, '');
      if (String(options.type || options.method || '').toUpperCase() === 'POST' && /(^|\\/)appointments$/.test(u)) {
        jqXHR.always(function () {
          var rec = {status: jqXHR.status, text: (jqXHR.responseText || '').slice(0, 4000), at: Date.now()};
          window.__gvcwBook = rec;
          try { sessionStorage.setItem('gvcwBook', JSON.stringify(rec)); } catch (e) {}
        });
      }
    });
  }
  return !!window.__gvcwHooked;
}
"""

BOOK_READ_JS = """
() => {
  let r = window.__gvcwBook || null;
  if (!r) { try { r = JSON.parse(sessionStorage.getItem('gvcwBook') || 'null'); } catch (e) {} }
  return {rec: r, url: location.href};
}
"""

LAST_ERROR_JS = """
() => {
  const msgs = [...document.querySelectorAll('.ajs-message, .alertify-notifier .ajs-message, .alert-danger, .parsley-errors-list li')]
    .map(e => (e.innerText || '').trim()).filter(Boolean);
  return msgs.slice(-3).join(' | ');
}
"""


def person_payload(cfg: Config, p: Person) -> dict:
    return {
        "type_id": cfg.type_id,
        "method": cfg.method,
        "email": p.account_email,
        "phone": p.phone,
        "phone_prefix_id": p.phone_prefix_id,
        "surname": p.surname,
        "firstname": p.firstname,
        "dob": p.dob,
        "passport": p.passport,
        "passport_expiry": p.passport_expiry,
        "gender_id": p.gender_id,
        "nationality_id": p.nationality_id,
    }


# ---------------------------------------------------------------- page actions

async def page_state(page) -> dict:
    try:
        return await page.evaluate(PAGE_STATE_JS)
    except Exception as exc:  # navigation in progress, closed tab, etc.
        return {"url": getattr(page, "url", ""), "hasForm": False, "hasLogin": False, "jq": False, "error": str(exc)}


async def fetch_day(page, cfg: Config, day: str) -> DayResult:
    try:
        res = await page.evaluate(SLOTS_JS, {"url": SLOTS_API, "body": slots_body(cfg, day)})
    except Exception as exc:
        return DayResult(day, ERROR, [], message=f"evaluate failed: {exc}")
    return classify_slots_result(day, res)


async def open_add_page(page, cfg: Config) -> bool:
    """Make sure this tab shows the Book Appointment form. Returns False if not logged in."""
    st = await page_state(page)
    if st.get("hasForm"):
        return True
    await page.goto(cfg.add_url, wait_until="domcontentloaded", timeout=60000)
    try:
        await page.wait_for_selector("form#appointment", timeout=30000)
        return True
    except Exception:
        return False
