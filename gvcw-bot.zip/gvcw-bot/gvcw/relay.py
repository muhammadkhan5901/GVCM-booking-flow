"""OTP relay and alerts through ntfy.

Phone side ("SMS to URL Forwarder" app) posts to <server>/ with JSON:
    {"topic": "<otp_topic>", "message": "P1 %from% %text%"}
so every relayed SMS starts with the person key. The bot keeps a stream open on
<server>/<otp_topic>/json and hands each code to whoever is waiting for that key.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import sys
import time

import httpx

from .config import Relay

log = logging.getLogger("gvcw.relay")


def extract_code(text: str, pattern: str) -> str | None:
    m = re.search(pattern, text)
    if not m:
        return None
    return m.group(1) if m.groups() else m.group(0)


def parse_relay_message(message: str, pattern: str) -> tuple[str, str] | None:
    """'P1 GVCW Your OTP is 123456' -> ('P1', '123456'). The key is the first word."""
    parts = message.strip().split(None, 1)
    if len(parts) < 2:
        return None
    key, rest = parts
    code = extract_code(rest, pattern)
    if not code:
        return None
    return key, code


class OtpRelay:
    def __init__(self, relay: Relay):
        self.relay = relay
        self._codes: dict[str, list[tuple[float, str]]] = {}
        self._event = asyncio.Event()
        self._task: asyncio.Task | None = None
        self._seen: set[str] = set()
        self.connected = False

    def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._run(), name="otp-relay")

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    def _store(self, msg_time: float, message: str) -> None:
        parsed = parse_relay_message(message, self.relay.otp_regex)
        if not parsed:
            log.warning("relay: message without a usable key/code: %r", message[:120])
            return
        key, code = parsed
        self._codes.setdefault(key, []).append((msg_time, code))
        log.info("relay: code received for %s", key)
        self._event.set()

    async def _run(self) -> None:
        url = f"{self.relay.server}/{self.relay.otp_topic}/json"
        backoff = 1.0
        while True:
            try:
                async with httpx.AsyncClient(timeout=httpx.Timeout(10.0, read=90.0)) as client:
                    async with client.stream("GET", url, params={"since": "5m"}) as resp:
                        resp.raise_for_status()
                        self.connected = True
                        backoff = 1.0
                        async for line in resp.aiter_lines():
                            if not line.strip():
                                continue
                            try:
                                ev = json.loads(line)
                            except ValueError:
                                continue
                            if ev.get("event") != "message":
                                continue
                            mid = str(ev.get("id") or f"{ev.get('time')}|{ev.get('message')}")
                            if mid in self._seen:  # reconnects re-deliver the last 5 minutes
                                continue
                            self._seen.add(mid)
                            self._store(float(ev.get("time") or time.time()), str(ev.get("message") or ""))
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.connected = False
                log.warning("relay stream dropped (%s), reconnecting in %.0fs", exc, backoff)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 15.0)

    async def wait_code(self, key: str, after_ts: float, timeout: float) -> str | None:
        """Newest code for `key` that was published after `after_ts` (minus small clock skew)."""
        deadline = time.monotonic() + timeout
        while True:
            fresh = [c for (t, c) in self._codes.get(key, []) if t >= after_ts - 5]
            if fresh:
                return fresh[-1]
            left = deadline - time.monotonic()
            if left <= 0:
                return None
            self._event.clear()
            try:
                await asyncio.wait_for(self._event.wait(), timeout=min(left, 1.0))
            except asyncio.TimeoutError:
                pass


class Alerts:
    """Beep on the PC and push to Ali's phone through the ntfy app."""

    def __init__(self, relay: Relay):
        self.relay = relay

    def beep(self, times: int = 3) -> None:
        try:
            if sys.platform == "win32":
                import winsound
                for _ in range(times):
                    winsound.Beep(1800, 350)
            else:
                print("\a" * times, end="", flush=True)
        except Exception:
            pass

    async def push(self, message: str, title: str = "GVCW bot", priority: int = 4) -> None:
        payload = {"topic": self.relay.notify_topic, "title": title, "message": message, "priority": priority}
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                await client.post(f"{self.relay.server}/", json=payload)
        except Exception as exc:
            log.warning("push failed: %s", exc)
