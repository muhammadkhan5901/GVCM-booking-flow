"""Orchestration: one scanner finds free dates, bookers race for distinct slots."""
from __future__ import annotations

import asyncio
import logging
import time
from datetime import date, datetime

from .booker import Booker
from .chrome import attach
from .config import Config
from .relay import Alerts, OtpRelay
from .site import BLOCKED, LOGGED_OUT, OPEN, fetch_day, month_dates, page_state

log = logging.getLogger("gvcw.runner")


class Runner:
    def __init__(self, cfg: Config, pw):
        self.cfg = cfg
        self.pw = pw
        self.alerts = Alerts(cfg.relay)
        self.pages: dict[str, object] = {}
        self.browsers: list = []

    async def attach_all(self) -> None:
        for p in self.cfg.persons:
            browser, page = await attach(self.pw, self.cfg, p)
            self.browsers.append(browser)
            self.pages[p.key] = page

    async def close(self) -> None:
        # Only drops our CDP connections; the Chrome windows (and sessions) stay open.
        for b in self.browsers:
            try:
                await b.close()
            except Exception:
                pass

    # ---------------------------------------------------------------- check / scan
    async def check(self) -> bool:
        dates = month_dates(self.cfg)
        probe = dates[0] if dates else None
        all_ok = True
        for p in self.cfg.persons:
            page = self.pages[p.key]
            st = await page_state(page)
            line = f"{p.key}: url={st.get('url')} form={st.get('hasForm')} loginForm={st.get('hasLogin')}"
            if probe and st.get("jq"):
                r = await fetch_day(page, self.cfg, probe)
                line += f" | probe {probe}: {r.kind} free={len(r.free)} {r.message[:60]}"
                if r.kind in (LOGGED_OUT, BLOCKED):
                    all_ok = False
            else:
                all_ok = False
            print(line)
            await asyncio.sleep(self.cfg.timing.request_gap_s)
        return all_ok

    async def scan(self) -> None:
        page = self.pages[self.cfg.persons[0].key]
        for day in month_dates(self.cfg):
            r = await fetch_day(page, self.cfg, day)
            free = ", ".join(f"{s.start}(id {s.id})" for s in r.free)
            print(f"{day}  {r.kind:10s} free={len(r.free)} {free} {r.message[:70]}")
            if r.kind in (LOGGED_OUT, BLOCKED):
                print("stopping: session problem")
                return
            await asyncio.sleep(self.cfg.timing.request_gap_s)

    # ---------------------------------------------------------------- full run
    async def run(self, dry_run: bool, rush_minutes: float, start_in_rush: bool) -> None:
        cfg, t = self.cfg, self.cfg.timing
        relay = OtpRelay(cfg.relay)
        relay.start()
        human_lock = asyncio.Lock()
        claimed: set[int] = set()
        bookers = [Booker(cfg, p, self.pages[p.key], relay, self.alerts, human_lock, claimed, dry_run)
                   for p in cfg.persons]
        for b in bookers:
            await b.prepare()
            await asyncio.sleep(1.0)

        dates = month_dates(cfg)
        if not dates:
            raise SystemExit(f"no bookable dates left in {cfg.month}")
        weekdays = [d for d in dates if datetime.strptime(d, "%d/%m/%Y").weekday() < 5]
        probes = (weekdays or dates)[:3]
        log.info("target %s: %d dates, probes %s, dry_run=%s", cfg.month, len(dates), probes, dry_run)
        await self.alerts.push(f"bot started for {cfg.month} ({'DRY RUN' if dry_run else 'LIVE'})", priority=3)

        month_open = False
        opened_at = time.monotonic() if start_in_rush else None
        tasks: set[asyncio.Task] = set()
        self._last_keepalive = time.monotonic()

        try:
            while any(not b.done for b in bookers):
                scanner = await self._scanner_page(bookers)
                if scanner is None:
                    await self.alerts.push("no logged-in window left, please log in again", priority=5)
                    await asyncio.to_thread(self.alerts.beep, 5)
                    await self._idle(bookers, 60)
                    continue

                if not month_open:
                    kinds = []
                    for d in probes:
                        r = await fetch_day(scanner, cfg, d)
                        kinds.append(r.kind)
                        log.info("probe %s -> %s %s", d, r.kind, r.message[:80])
                        await asyncio.sleep(t.request_gap_s)
                    if OPEN in kinds:
                        month_open = True
                        if opened_at is None:
                            opened_at = time.monotonic()
                        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        log.warning("MONTH %s IS OPEN (first seen %s)", cfg.month, stamp)
                        await self.alerts.push(f"{cfg.month} slots are OPEN (seen {stamp})", priority=5)
                        await asyncio.to_thread(self.alerts.beep, 4)
                    else:
                        if any(k in (LOGGED_OUT, BLOCKED) for k in kinds):
                            await self.alerts.push(f"scanner window problem: {kinds}", priority=4)
                        await self._idle(bookers, t.closed_check_every_s)
                        continue

                # sweep the month and hand free dates to idle bookers
                for day in dates:
                    idle = [b for b in bookers if not b.done and not b.busy]
                    if not idle:
                        break
                    r = await fetch_day(scanner, cfg, day)
                    if r.kind in (LOGGED_OUT, BLOCKED):
                        log.warning("scanner %s on %s, switching window", r.kind, day)
                        break
                    unclaimed = [s for s in r.free if s.id not in claimed]
                    if unclaimed:
                        log.warning("%s: %d free slot(s): %s", day, len(unclaimed), [s.start for s in unclaimed])
                        for b in idle[: len(unclaimed)]:
                            b.busy = True
                            task = asyncio.create_task(b.attempt(day), name=f"attempt-{b.p.key}")
                            tasks.add(task)
                            task.add_done_callback(tasks.discard)
                    await asyncio.sleep(t.request_gap_s)

                in_rush = opened_at is not None and time.monotonic() - opened_at < rush_minutes * 60
                if any(b.busy for b in bookers) or in_rush:
                    await asyncio.sleep(t.sweep_pause_s)
                else:
                    await self._idle(bookers, t.monitor_sweep_every_s)
        finally:
            for task in list(tasks):
                if not task.done():
                    await asyncio.wait({task}, timeout=t.book_timeout_s + t.captcha_timeout_s)
            await relay.stop()
            print("\n==== result ====")
            for b in bookers:
                print(f"{b.p.key}: {b.result or 'not booked'}")

    async def _scanner_page(self, bookers):
        """Prefer a logged-in window of someone who is not mid-booking."""
        ordered = sorted(bookers, key=lambda b: (b.busy, b.done))
        for b in ordered:
            st = await page_state(b.page)
            if st.get("jq") and not st.get("hasLogin"):
                return b.page
        return None

    async def _idle(self, bookers, seconds: float) -> None:
        end = time.monotonic() + seconds
        ka = self.cfg.timing.keepalive_every_s
        while time.monotonic() < end:
            await asyncio.sleep(min(5.0, max(0.0, end - time.monotonic())))
            if ka and time.monotonic() - self._last_keepalive >= ka:
                self._last_keepalive = time.monotonic()
                await self._keepalive(bookers)

    async def _keepalive(self, bookers) -> None:
        dates = month_dates(self.cfg) or [date.today().strftime("%d/%m/%Y")]
        for b in bookers:
            if b.done or b.busy:
                continue
            r = await fetch_day(b.page, self.cfg, dates[0])
            if r.kind in (LOGGED_OUT, BLOCKED):
                await b.call_human(f"session lost ({r.kind}), please log in again in this window")
            elif r.kind == OPEN or r.kind == "closed":
                log.info("%s keepalive ok (%s)", b.p.key, r.kind)
            else:
                log.warning("%s keepalive got %s: %s", b.p.key, r.kind, r.message[:100])
            await asyncio.sleep(self.cfg.timing.request_gap_s)
