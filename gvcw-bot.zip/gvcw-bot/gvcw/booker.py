"""One Booker per person: drives that person's own logged-in Chrome tab through
search -> pick slot -> request OTP -> enter OTP -> (human solves CAPTCHA) -> Book.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from datetime import datetime

from .config import Config, Person
from .relay import Alerts, OtpRelay
from .site import (
    BOOK_HOOK_JS, BOOK_READ_JS, CAPTCHA_TOKEN_JS, CLOSED, ERROR, FILL_FORM_JS, LAST_ERROR_JS, OPEN, OTP_API_PART, SET_DATE_JS,
    SLOT_SELECTED_JS, SLOTS_API, DayResult, Slot, open_add_page, page_state, person_payload, success_result,
)

OTP_RESEND_LOCK_S = 125  # the site hides "Request OTP" for 2 minutes after each request

BOOKED, REFUSED, UNCERTAIN = "BOOKED", "REFUSED", "UNCERTAIN"
# A refusal containing one of these clearly means "not booked", so trying another slot is safe.
SAFE_REFUSAL_WORDS = ("otp", "one time", "captcha", "no longer available", "not available", "unavailable",
                      "fully booked", "expired", "wrong code", "invalid code", "slot")


class Booker:
    def __init__(self, cfg: Config, person: Person, page, relay: OtpRelay, alerts: Alerts,
                 human_lock: asyncio.Lock, claimed: set[int], dry_run: bool):
        self.cfg = cfg
        self.p = person
        self.page = page
        self.relay = relay
        self.alerts = alerts
        self.human_lock = human_lock
        self.claimed = claimed
        self.dry_run = dry_run
        self.done = False
        self.busy = False
        self.result = ""
        self.last_otp_request = 0.0
        self.otp_code: str | None = None
        self.otp_code_at = 0.0
        self.fill_report: dict = {}
        self.book_clicked = False
        page.set_default_timeout(10000)
        self.log = logging.getLogger(f"gvcw.{person.key}")
        self.shots = cfg.logs_dir / "screens"
        self.shots.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------ helpers
    async def shot(self, tag: str) -> None:
        name = f"{datetime.now():%Y%m%d-%H%M%S}-{self.p.key}-{tag}.png"
        try:
            await self.page.screenshot(path=str(self.shots / name), full_page=True)
        except Exception as exc:
            self.log.warning("screenshot failed: %s", exc)

    async def last_error(self) -> str:
        try:
            return await self.page.evaluate(LAST_ERROR_JS)
        except Exception:
            return ""

    async def call_human(self, text: str) -> None:
        self.log.warning("HUMAN NEEDED: %s", text)
        await asyncio.to_thread(self.alerts.beep, 3)
        await self.alerts.push(f"{self.p.key}: {text}")

    # ------------------------------------------------------------ steps
    async def prepare(self) -> bool:
        """Open the Book Appointment form and fill this person's details (no requests that book anything)."""
        if not await open_add_page(self.page, self.cfg):
            await self.call_human("not logged in, please log in in this window")
            return False
        payload = person_payload(self.cfg, self.p)
        r1 = await self.page.evaluate(FILL_FORM_JS, {**payload, "step": "type"})
        await asyncio.sleep(2.0)  # changing the type reloads dependent fields
        r2 = await self.page.evaluate(FILL_FORM_JS, {**payload, "step": "all"})
        res = {**r1, **r2}
        self.fill_report = res
        bad = {k: v for k, v in res.items() if v not in ("ok", "kept site value")}
        if bad:
            self.log.warning("form fields not set as expected: %s", bad)
        else:
            self.log.info("form filled")
        return True

    async def search_day(self, day: str) -> DayResult:
        await self.page.evaluate(SET_DATE_JS, day)
        try:
            async with self.page.expect_response(
                lambda r: SLOTS_API in r.url and r.request.method == "PUT", timeout=20000
            ) as info:
                await self.page.click("#btn-search")
            resp = await info.value
            data = await resp.json()
        except Exception as exc:
            msg = await self.last_error()
            return DayResult(day, ERROR, [], message=f"{exc} {msg}".strip())
        if str(data.get("code", "")).upper() == "SUCCESS":
            return success_result(day, data)
        return DayResult(day, CLOSED, [], message=str(data.get("message") or data.get("code")))

    def claim(self, res: DayResult) -> Slot | None:
        for s in res.free:
            if s.id not in self.claimed:
                self.claimed.add(s.id)
                return s
        return None

    async def select_slot(self, slot: Slot) -> bool:
        sel = f"#t_{slot.id}"
        try:
            await self.page.wait_for_selector(sel, timeout=8000)
            await self.page.click(sel)
            st = await self.page.evaluate(SLOT_SELECTED_JS, slot.id)
        except Exception as exc:
            self.log.warning("could not click slot %s: %s", slot.id, exc)
            return False
        return bool(st.get("selected") and st.get("time"))

    async def request_otp(self) -> float | None:
        wait = self.last_otp_request + OTP_RESEND_LOCK_S - time.time()
        if wait > 0:
            self.log.info("OTP button locked by the site, waiting %.0fs", wait)
            await asyncio.sleep(wait)
        try:
            await self.page.wait_for_selector("#btn-onetimepassword", state="visible", timeout=15000)
            t0 = time.time()
            async with self.page.expect_response(lambda r: OTP_API_PART in r.url, timeout=25000) as info:
                await self.page.click("#btn-onetimepassword")
            resp = await info.value
            data = await resp.json()
        except Exception as exc:
            self.log.warning("OTP request failed: %s %s", exc, await self.last_error())
            return None
        if str(data.get("code", "")).upper() != "SUCCESS":
            self.log.warning("OTP request refused: %s", data.get("message"))
            return None
        self.last_otp_request = t0
        self.otp_code = None
        self.log.info("OTP requested, waiting for SMS")
        return t0

    async def wait_otp(self, t0: float) -> str | None:
        """Code from the SMS relay, or typed by hand into the OTP box in this window."""
        start = time.monotonic()
        deadline = start + self.cfg.timing.otp_timeout_s
        warned = False
        while time.monotonic() < deadline:
            code = await self.relay.wait_code(self.p.key, t0, timeout=1.0)
            if code:
                await self.page.fill("#onetimepassword", code)
                self.log.info("OTP filled from relay")
                return code
            try:
                manual = (await self.page.input_value("#onetimepassword")).strip()
            except Exception:
                manual = ""
            if len(manual) >= 4:
                self.log.info("OTP typed by hand")
                return manual
            if not warned and time.monotonic() - start > 45:
                warned = True
                await self.call_human("no OTP after 45s, check the phone and type it into the OTP box")
        return None

    async def _captcha_token(self) -> str:
        try:
            return await self.page.evaluate(CAPTCHA_TOKEN_JS)
        except Exception:
            return ""

    async def captcha_and_book(self) -> tuple[str, str]:
        """Returns (BOOKED | REFUSED | UNCERTAIN, message).

        REFUSED means the server clearly said no, so it is safe to try another slot.
        UNCERTAIN means Book was clicked but the outcome is unclear: we never retry
        that person automatically, to avoid booking anyone twice.
        """
        async with self.human_lock:  # one CAPTCHA at a time for the human
            try:
                await self.page.bring_to_front()
                await self.page.locator("#recaptcha").scroll_into_view_if_needed(timeout=5000)
            except Exception:
                pass
            if not await self._captcha_token():
                await self.call_human("solve the CAPTCHA in this window now (bot will click Book)")
            deadline = time.monotonic() + self.cfg.timing.captcha_timeout_s
            while not await self._captcha_token():
                if time.monotonic() > deadline:
                    return REFUSED, "CAPTCHA not solved in time"
                await asyncio.sleep(0.4)
            try:
                box = self.page.locator("#submitinfo")
                if await box.is_visible() and not await box.is_checked():
                    await box.check()
                await self.page.evaluate(BOOK_HOOK_JS)
                await self.page.click("#btn-new-appointment", timeout=8000)
            except Exception as exc:
                return REFUSED, f"could not click Book: {exc}"
            self.book_clicked = True
            self.log.info("Book clicked, waiting for the server")
        return await self._book_outcome()

    async def _book_outcome(self) -> tuple[str, str]:
        deadline = time.monotonic() + self.cfg.timing.book_timeout_s
        while time.monotonic() < deadline:
            try:
                st = await self.page.evaluate(BOOK_READ_JS)
            except Exception:
                await asyncio.sleep(0.3)  # page is switching to the result view
                continue
            rec = st.get("rec")
            if rec:
                text = str(rec.get("text") or "")
                try:
                    data = json.loads(text)
                except ValueError:
                    return UNCERTAIN, f"HTTP {rec.get('status')} non-JSON reply: {text[:120]}"
                code = str(data.get("code", "")).upper()
                msg = str(data.get("message") or code)
                if code == "SUCCESS":
                    try:
                        await self.page.wait_for_url("**/appointments/result/**", timeout=10000)
                    except Exception:
                        pass
                    return BOOKED, f"reference {data.get('returnobject')}"
                if any(w in msg.lower() for w in SAFE_REFUSAL_WORDS):
                    return REFUSED, msg
                return UNCERTAIN, f"{code}: {msg}"
            await asyncio.sleep(0.3)
        return UNCERTAIN, f"no reply within {self.cfg.timing.book_timeout_s:.0f}s"

    async def _finish(self, result: str, title: str) -> str:
        self.done = True
        self.result = result
        self.log.warning(result)
        await self.alerts.push(f"{self.p.key}: {result}", title=title, priority=5)
        await asyncio.to_thread(self.alerts.beep, 6)
        return "booked" if title == "BOOKED" else "uncertain"

    # ------------------------------------------------------------ one attempt
    async def attempt(self, day: str) -> str:
        """Try to book one slot on `day`. Returns 'booked', 'dry', or 'retry'."""
        self.busy = True
        self.book_clicked = False
        slot: Slot | None = None
        try:
            if not (await page_state(self.page)).get("hasForm"):
                if not await self.prepare():
                    return "retry"
            res = await self.search_day(day)
            if res.kind != OPEN or not res.free:
                self.log.info("%s: nothing for me (%s %s)", day, res.kind, res.message[:80])
                return "retry"
            slot = self.claim(res)
            if not slot:
                self.log.info("%s: all free slots already taken by the others", day)
                return "retry"
            if not await self.select_slot(slot):
                self.log.info("%s %s: slot vanished", day, slot.start)
                return "retry"
            self.log.info("%s %s: slot selected (id %s)", day, slot.start, slot.id)
            if self.dry_run:
                await self.shot("dry-run-selected")
                self.done = True
                self.result = f"DRY RUN stopped before OTP at {day} {slot.start}"
                await self.alerts.push(f"{self.p.key}: {self.result}", priority=3)
                return "dry"

            reuse = bool(self.otp_code and time.time() - self.otp_code_at < 240)
            if reuse:
                try:
                    reuse = await self.page.locator("#onetimepassword").is_visible()
                except Exception:
                    reuse = False
            if reuse:
                await self.page.fill("#onetimepassword", self.otp_code)
                self.log.info("re-using the OTP from the previous attempt")
            else:
                t0 = await self.request_otp()
                if not t0:
                    return "retry"
                code = await self.wait_otp(t0)
                if not code:
                    await self.call_human("OTP never arrived, will retry")
                    return "retry"
                self.otp_code, self.otp_code_at = code, time.time()

            outcome, msg = await self.captcha_and_book()
            await self.shot(outcome.lower())
            if outcome == BOOKED:
                return await self._finish(f"BOOKED {day} {slot.start} ({msg})", "BOOKED")
            if outcome == UNCERTAIN:
                return await self._finish(f"UNCERTAIN after Book at {day} {slot.start}: {msg}. "
                                          f"Check this window and 'My Appointments' yourself", "CHECK NOW")
            self.log.warning("%s %s: booking refused: %s", day, slot.start, msg)
            if "otp" in msg.lower() or "code" in msg.lower():
                self.otp_code = None
            return "retry"
        except Exception as exc:
            self.log.exception("attempt crashed: %s", exc)
            if self.book_clicked:
                return await self._finish(f"UNCERTAIN: crashed after Book was clicked ({exc}). Check this window", "CHECK NOW")
            return "retry"
        finally:
            self.busy = False
            if slot and not self.done:
                self.claimed.discard(slot.id)
