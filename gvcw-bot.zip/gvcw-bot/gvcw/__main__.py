"""Command line entry point:  python -m gvcw <command> [options]"""
from __future__ import annotations

import argparse
import asyncio
import logging
import sys
import time
from datetime import datetime

from .config import ConfigError, load_config


def setup_logging(cfg) -> None:
    cfg.logs_dir.mkdir(parents=True, exist_ok=True)
    logfile = cfg.logs_dir / f"bot-{datetime.now():%Y%m%d}.log"
    fmt = "%(asctime)s %(levelname)-7s %(name)-12s %(message)s"
    logging.basicConfig(level=logging.INFO, format=fmt,
                        handlers=[logging.StreamHandler(sys.stdout),
                                  logging.FileHandler(logfile, encoding="utf-8")])
    logging.getLogger("httpx").setLevel(logging.WARNING)


async def _with_runner(cfg, fn):
    from playwright.async_api import async_playwright
    from .runner import Runner
    async with async_playwright() as pw:
        runner = Runner(cfg, pw)
        await runner.attach_all()
        try:
            return await fn(runner)
        finally:
            await runner.close()


async def cmd_fill(runner) -> None:
    from .booker import Booker
    from .relay import OtpRelay
    lock, claimed = asyncio.Lock(), set()
    for p in runner.cfg.persons:
        b = Booker(runner.cfg, p, runner.pages[p.key], OtpRelay(runner.cfg.relay), runner.alerts, lock, claimed, True)
        await b.prepare()
        print(f"{p.key}: {b.fill_report}")


async def cmd_relay_test(cfg, key: str, minutes: float) -> None:
    from .relay import OtpRelay
    relay = OtpRelay(cfg.relay)
    relay.start()
    t0 = time.time()
    print(f"Waiting up to {minutes:.0f} min for an SMS relayed with key '{key}'. Send any SMS containing a 4-8 digit number to that phone.")
    code = await relay.wait_code(key, t0, minutes * 60)
    await relay.stop()
    print(f"received code: {code}" if code else "nothing received")


async def cmd_notify_test(cfg) -> None:
    from .relay import Alerts
    a = Alerts(cfg.relay)
    await asyncio.to_thread(a.beep, 2)
    await a.push("test alert from the GVCW bot", priority=4)
    print("beeped and pushed a test notification")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="gvcw")
    ap.add_argument("-c", "--config", default="config.yaml")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("launch", help="open one Chrome window per person on the login page")
    sub.add_parser("check", help="attach to all windows and report session state (1 request per person)")
    sub.add_parser("scan", help="read-only sweep of the target month (1 request per date)")
    sub.add_parser("fill", help="fill each person's form without searching or booking")
    r = sub.add_parser("run", help="watch and book")
    r.add_argument("--dry-run", action="store_true", help="stop after selecting a slot, before OTP")
    r.add_argument("--rush-minutes", type=float, default=60, help="fast sweeping for this long after the month opens")
    r.add_argument("--rush-now", action="store_true", help="treat the start as release time (fast sweeping)")
    rt = sub.add_parser("relay-test", help="wait for one relayed SMS from a phone")
    rt.add_argument("key")
    rt.add_argument("--minutes", type=float, default=5)
    sub.add_parser("notify-test", help="beep and send a test push to your phone")
    args = ap.parse_args(argv)

    try:
        cfg = load_config(args.config)
    except ConfigError as exc:
        print(f"config error: {exc}")
        return 2
    setup_logging(cfg)

    if args.cmd == "launch":
        from .chrome import launch_all
        launch_all(cfg)
        print("Log in each window yourself (CAPTCHA), then run:  python -m gvcw check")
        return 0
    if args.cmd == "relay-test":
        asyncio.run(cmd_relay_test(cfg, args.key, args.minutes))
        return 0
    if args.cmd == "notify-test":
        asyncio.run(cmd_notify_test(cfg))
        return 0
    try:
        if args.cmd == "check":
            ok = asyncio.run(_with_runner(cfg, lambda rn: rn.check()))
            return 0 if ok else 1
        if args.cmd == "scan":
            asyncio.run(_with_runner(cfg, lambda rn: rn.scan()))
        elif args.cmd == "fill":
            asyncio.run(_with_runner(cfg, cmd_fill))
        elif args.cmd == "run":
            asyncio.run(_with_runner(cfg, lambda rn: rn.run(args.dry_run, args.rush_minutes, args.rush_now)))
    except KeyboardInterrupt:
        print("stopped by user (Chrome windows stay open and logged in)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
