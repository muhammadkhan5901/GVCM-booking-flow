"""Start one normal Chrome window per person and attach to it.

Each person gets an own Chrome profile folder (own cookies = own GVCW session).
Chrome keeps running independently of this script, so if the bot crashes or is
restarted it just re-attaches: nobody has to log in (and solve a CAPTCHA) again.
"""
from __future__ import annotations

import logging
import subprocess
import urllib.request
from pathlib import Path

from .config import Config, Person

log = logging.getLogger("gvcw.chrome")


def is_up(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/json/version", timeout=1.5) as r:
            return r.status == 200
    except Exception:
        return False


def launch_all(cfg: Config) -> None:
    chrome = Path(cfg.chrome_path)
    if not chrome.exists():
        raise SystemExit(f"Chrome not found at {chrome}. Set chrome_path in config.yaml.")
    for p in cfg.persons:
        if is_up(p.port):
            log.info("%s: Chrome already running on port %s", p.key, p.port)
            continue
        profile = cfg.profiles_dir / p.key
        profile.mkdir(parents=True, exist_ok=True)
        args = [
            str(chrome),
            f"--remote-debugging-port={p.port}",
            f"--user-data-dir={profile}",
            "--no-first-run",
            "--no-default-browser-check",
            "--new-window",
            cfg.login_url,
        ]
        subprocess.Popen(args, close_fds=True)
        log.info("%s: started Chrome (profile %s, port %s)", p.key, profile, p.port)


async def attach(pw, cfg: Config, person: Person):
    """Return (browser, page) for this person's GVCW tab, opening one if needed."""
    if not is_up(person.port):
        raise RuntimeError(f"{person.key}: Chrome is not running on port {person.port}. Run 'launch' first.")
    browser = await pw.chromium.connect_over_cdp(f"http://127.0.0.1:{person.port}")
    if not browser.contexts:
        raise RuntimeError(f"{person.key}: no browser context found")
    ctx = browser.contexts[0]
    pages = [pg for pg in ctx.pages if cfg.host in (pg.url or "")]
    page = pages[0] if pages else await ctx.new_page()
    if not pages:
        await page.goto(cfg.login_url, wait_until="domcontentloaded", timeout=60000)
    return browser, page
