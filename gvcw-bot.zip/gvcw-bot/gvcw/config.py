"""Load and validate config.yaml."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

import yaml

GENDER_IDS = {"FEMALE": "1", "MALE": "2", "OTHER": "3"}
_DATE_RE = re.compile(r"^\d{2}/\d{2}/\d{4}$")
_MONTH_RE = re.compile(r"^\d{4}-\d{2}$")


class ConfigError(ValueError):
    pass


@dataclass
class Person:
    key: str
    port: int
    account_email: str
    phone: str
    surname: str
    firstname: str
    dob: str
    passport: str
    passport_expiry: str
    gender: str
    nationality_id: int = 197
    phone_prefix_id: int = 197

    @property
    def gender_id(self) -> str:
        return GENDER_IDS[self.gender]


@dataclass
class Timing:
    request_gap_s: float = 2.0
    sweep_pause_s: float = 5.0
    closed_check_every_s: float = 180.0
    monitor_sweep_every_s: float = 300.0
    keepalive_every_s: float = 600.0
    otp_timeout_s: float = 150.0
    captcha_timeout_s: float = 240.0
    book_timeout_s: float = 90.0


@dataclass
class Relay:
    server: str
    otp_topic: str
    notify_topic: str
    otp_regex: str = r"\b(\d{4,8})\b"


@dataclass
class Config:
    base_url: str
    chrome_path: str
    profiles_dir: Path
    logs_dir: Path
    vac_id: int
    type_id: int
    method: int
    travel_purpose: int
    month: str
    skip_weekdays: list[int]
    timing: Timing
    relay: Relay
    persons: list[Person] = field(default_factory=list)

    @property
    def login_url(self) -> str:
        return self.base_url.rstrip("/") + "/login/appointments/en"

    @property
    def add_url(self) -> str:
        return self.base_url.rstrip("/") + "/appointments/add"

    @property
    def host(self) -> str:
        return self.base_url.split("//", 1)[-1].split("/", 1)[0]

    def month_bounds(self) -> tuple[int, int]:
        y, m = self.month.split("-")
        return int(y), int(m)


def _req(d: dict, key: str, where: str):
    if key not in d or d[key] in (None, ""):
        raise ConfigError(f"missing '{key}' in {where}")
    return d[key]


def _check_date(value: str, what: str) -> str:
    value = str(value).strip()
    if not _DATE_RE.match(value):
        raise ConfigError(f"{what} must be DD/MM/YYYY, got '{value}'")
    dd, mm, yy = (int(x) for x in value.split("/"))
    try:
        date(yy, mm, dd)
    except ValueError as exc:
        raise ConfigError(f"{what} is not a real date: '{value}'") from exc
    return value


def load_config(path: str | Path) -> Config:
    path = Path(path)
    if not path.exists():
        raise ConfigError(f"config file not found: {path} (copy config.example.yaml to config.yaml)")
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    root = path.resolve().parent

    appt = raw.get("appointment", {}) or {}
    target = raw.get("target", {}) or {}
    relay_raw = raw.get("relay", {}) or {}

    month = str(_req(target, "month", "target"))
    if not _MONTH_RE.match(month):
        raise ConfigError(f"target.month must be YYYY-MM, got '{month}'")

    skip = [int(x) for x in (target.get("skip_weekdays") or [])]
    if any(x < 0 or x > 6 for x in skip):
        raise ConfigError("target.skip_weekdays values must be 0 (Mon) .. 6 (Sun)")

    relay = Relay(
        server=str(relay_raw.get("server", "https://ntfy.sh")).rstrip("/"),
        otp_topic=str(_req(relay_raw, "otp_topic", "relay")),
        notify_topic=str(_req(relay_raw, "notify_topic", "relay")),
        otp_regex=str(relay_raw.get("otp_regex", r"\b(\d{4,8})\b")),
    )
    for name, topic in (("otp_topic", relay.otp_topic), ("notify_topic", relay.notify_topic)):
        if "CHANGE-ME" in topic or len(topic) < 20:
            raise ConfigError(f"relay.{name} must be a long random string (20+ chars), not the example value")
    if relay.otp_topic == relay.notify_topic:
        raise ConfigError("relay.otp_topic and relay.notify_topic must be different")
    re.compile(relay.otp_regex)

    timing = Timing(**(raw.get("timing") or {}))

    persons: list[Person] = []
    for i, p in enumerate(raw.get("persons") or []):
        where = f"persons[{i}]"
        gender = str(_req(p, "gender", where)).upper()
        if gender not in GENDER_IDS:
            raise ConfigError(f"{where}.gender must be one of {list(GENDER_IDS)}")
        phone = str(_req(p, "phone", where)).strip().lstrip("+")
        if phone.startswith("92"):
            phone = phone[2:]
        if phone.startswith("0"):
            phone = phone[1:]
        if not phone.isdigit() or len(phone) != 10:
            raise ConfigError(f"{where}.phone must be the 10-digit number without 0/+92, e.g. 3001234567")
        persons.append(
            Person(
                key=str(_req(p, "key", where)).strip(),
                port=int(_req(p, "port", where)),
                account_email=str(_req(p, "account_email", where)).strip(),
                phone=phone,
                surname=str(_req(p, "surname", where)).strip().upper(),
                firstname=str(_req(p, "firstname", where)).strip().upper(),
                dob=_check_date(_req(p, "dob", where), f"{where}.dob"),
                passport=str(_req(p, "passport", where)).strip().upper(),
                passport_expiry=_check_date(_req(p, "passport_expiry", where), f"{where}.passport_expiry"),
                gender=gender,
                nationality_id=int(p.get("nationality_id", 197)),
                phone_prefix_id=int(p.get("phone_prefix_id", 197)),
            )
        )
    if not persons:
        raise ConfigError("no persons configured")
    keys = [p.key for p in persons]
    ports = [p.port for p in persons]
    if len(set(keys)) != len(keys):
        raise ConfigError("person keys must be unique")
    if len(set(ports)) != len(ports):
        raise ConfigError("person ports must be unique")
    for p in persons:
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,16}", p.key):
            raise ConfigError(f"person key '{p.key}' must be short letters/digits only (it is used in the SMS relay)")
        if not 1024 < p.port < 65535:
            raise ConfigError(f"person {p.key}: port must be between 1025 and 65534")

    return Config(
        base_url=str(raw.get("base_url", "https://pk-gr-services.gvcworld.eu")).rstrip("/"),
        chrome_path=str(raw.get("chrome_path", r"C:\Program Files\Google\Chrome\Application\chrome.exe")),
        profiles_dir=(root / str(raw.get("profiles_dir", "profiles"))).resolve(),
        logs_dir=(root / str(raw.get("logs_dir", "logs"))).resolve(),
        vac_id=int(appt.get("vac_id", 137)),
        type_id=int(appt.get("type_id", 26)),
        method=int(appt.get("method", 1)),
        travel_purpose=int(appt.get("travel_purpose", -1)),
        month=month,
        skip_weekdays=skip,
        timing=timing,
        relay=relay,
        persons=persons,
    )
